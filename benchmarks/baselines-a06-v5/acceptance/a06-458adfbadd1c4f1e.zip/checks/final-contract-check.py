"""Read the pinned unmerged A05 contract without integrating its branch."""
import json
import subprocess
import sys
import types
from pathlib import Path

commit = "26ff8582601f1c92f58b476ebf726d99ca7eac30"
for name in ["schemas.benchmark_v2", "evaluation.benchmark_v2"]:
    source = subprocess.check_output(["git", "show", f"{commit}:{name.replace('.', '/')}.py"])
    module = types.ModuleType(name)
    module.__file__ = name.replace('.', '/') + ".py"
    sys.modules[name] = module
    exec(compile(source, module.__file__, "exec"), module.__dict__)

from evaluation.scanner_baseline import score_exports, write
from schemas.benchmark_v2 import BenchmarkObservationV2

attempt = Path("artifacts/a06/final-acceptance-01")
counts = {}
for view in ["sast", "dast", "union"]:
    observations = json.loads((attempt / f"{view}-observations-v2.json").read_text())
    for observation in observations:
        BenchmarkObservationV2.model_validate(observation)
        if view == "dast":
            assert not {"source_file", "line_start", "line_end"} & observation.keys()
    counts[view] = len(observations)
output = score_exports(attempt, Path("artifacts/a06/final-a05-scores"))
write(output / "contract-check.json", {
    "a05_commit": commit, "observation_counts": counts,
    "all_real_exports_schema_valid": True,
    "real_exports_scored_separately": True,
    "dast_has_no_source_lines": True,
    "kind": "A06_contract_acceptance_not_A07_repeated_measurement",
})
print(json.dumps(counts))
