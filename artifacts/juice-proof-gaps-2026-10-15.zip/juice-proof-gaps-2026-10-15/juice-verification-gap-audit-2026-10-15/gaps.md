# Неподтвержденные случаи: операционная диагностика

Положительных: 27. Runtime confirmed: 7. Осталось: 20.

Сопоставление кандидата не доказывает, что он описывает правильную причину.

| Случай | Семейство | Блокер | Наблюдения |
|---|---|---|---|
| JS-AUTHZ-001 | authorization | no_registered_runtime_protocol | server.ts:520 |
| JS-AUTHZ-002 | authorization | no_registered_runtime_protocol | models/user.ts:94 |
| JS-BIZ-001 | business-logic | no_registered_runtime_protocol | routes/basketItems.ts:93 |
| JS-BIZ-002 | business-logic | no_registered_runtime_protocol | routes/coupon.ts:14 |
| JS-BOLA-003 | access-control | no_registered_runtime_protocol | routes/updateProductReviews.ts:18 |
| JS-BOLA-004 | access-control | no_registered_runtime_protocol | models/feedback.ts:31 |
| JS-CAPTCHA-001 | anti-automation | no_registered_runtime_protocol | routes/captcha.ts:37; routes/captcha.ts:31 |
| JS-CODE-001 | code-evaluation | no_registered_runtime_protocol | routes/userProfile.ts:65 |
| JS-CRYPTO-001 | weak-cryptography | source_property_review_required | lib/insecurity.ts:41 |
| JS-DATA-001 | sensitive-data-exposure | no_registered_runtime_protocol | routes/currentUser.ts:30 |
| JS-DATA-002 | sensitive-data-exposure | no_registered_runtime_protocol | routes/metrics.ts:92 |
| JS-FILE-002 | file-validation | no_registered_runtime_protocol | routes/fileServer.ts:27 |
| JS-NOSQL-001 | nosql-injection | no_registered_runtime_protocol | routes/updateProductReviews.ts:18 |
| JS-NOSQL-002 | nosql-injection | no_registered_runtime_protocol | routes/trackOrder.ts:18 |
| JS-PATH-001 | path-traversal | no_registered_runtime_protocol | routes/fileUpload.ts:34 |
| JS-RATE-001 | rate-limiting | no_registered_runtime_protocol | server.ts:365 |
| JS-SSRF-001 | ssrf | no_registered_runtime_protocol | routes/profileImageUrlUpload.ts:24 |
| JS-XSS-001 | xss | no_registered_runtime_protocol | frontend/src/app/search-result/search-result.component.ts:144 |
| JS-XSS-002 | xss | no_registered_runtime_protocol | frontend/src/app/search-result/search-result.component.ts:111 |
| JS-XXE-001 | xml-external-entities | no_registered_runtime_protocol | lib/xml.ts:35; lib/xml.ts:35 |
