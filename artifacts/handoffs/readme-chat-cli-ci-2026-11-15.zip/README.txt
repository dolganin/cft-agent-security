Readme/UI/CLI/CI acceptance evidence, 2026-11-15.
No configuration files, database, API keys, node_modules or virtualenv are included.
Original report bytes and absolute provenance references are retained. Resolve execution-<id> to evidence/execution-<id>.json within that run folder.
This is a controlled demo acceptance package, not Juice Shop benchmark results.
