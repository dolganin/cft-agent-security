# B09 single-run handoff

One valid final run, not a reproducibility series. The sibling
`b09-single-2026-10-15` directory is an explicitly invalid integration attempt.
Never average it with this final run or call it another successful repetition.

`evaluation/summary.json`: deterministic current results.
`evaluation/confirmed-review.json`: all eight CONFIRMED observations.
`evaluation/family-metrics.json`, `case-losses.json`: remaining coverage gaps.
`comparison/`: verified historical A08 reference and historical A06 scorecards.
`cleanup-audit.json`, `offline-replay.json`: lifecycle and evaluator checks.
`benchmark/`: frozen evaluator inputs, not producer input.
`pipeline/`: raw SAST, Scout, reports, action traces, execution/audit and B06 trials.

Verify every entry in the archive's MANIFEST-SHA256.json before use.
From a checkout containing app.b09_score, after extracting the archive:

```bash
python -m app.b09_score \
  --artifacts /absolute/path/to/b09-single-2026-10-15-final \
  --dataset /absolute/path/to/b09-single-2026-10-15-final/benchmark/ground_truth.yaml
```

No Docker, model, target checkout or API key is needed for rescoring.
The command rewrites only derived evaluation outputs and idempotently indexes
exact B06 execution records/audit lines in the canonical evidence directory;
original B06 records remain unchanged. The stored offline-replay SHA256 list
must still match the derived evaluation files afterward.

Do not invoke app.b09_run to rescore: that starts a new real benchmark attempt.
MTTR, agent reproducibility and scoring accuracy remain unmeasured.
