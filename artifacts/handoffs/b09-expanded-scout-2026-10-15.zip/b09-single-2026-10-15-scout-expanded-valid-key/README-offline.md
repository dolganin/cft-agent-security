# Пересчёт результатов без модели и Docker

Архив содержит фактический B09 и отдельную Docker-приёмку исправления реестра.
Это один benchmark-прогон. Приёмка исправления не увеличивает число его TP.

В репозитории cft-security-agent с текущим scorer и установленными зависимостями:

```bash
python -m app.b09_score \
  --artifacts /absolute/path/b09-single-2026-10-15-scout-expanded-valid-key \
  --dataset /absolute/path/b09-single-2026-10-15-scout-expanded-valid-key/benchmark/ground_truth.yaml
```

Команда использует только сохранённые данные и обновляет `evaluation`.
Для проверки передачи сверить каждый файл с `MANIFEST-SHA256.json` в ZIP.
SHA256 самого ZIP сохранён рядом в файле `.zip.sha256`.

Версия замера: base git commit указан в `implementation-identity.json`.
Точные восемь modified source files приложены в `implementation/run-source`;
их SHA256 совпадают с identity. Patch в `implementation/run-changes.patch`
относится к base commit. `implementation/post-run-fix` относится к исправлению,
сделанному после замера; не применять его результаты к прошлым метрикам.

Окружение, target checkout и API-ключ в архив не включены.
