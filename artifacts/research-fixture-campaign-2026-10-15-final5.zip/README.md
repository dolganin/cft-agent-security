# Private fixture campaign acceptance

Three real Docker protocols were run through the research campaign bridge. The research/model step was scripted; fixtures, Validator, Executor, persisted Evidence, audit, request accounting, target source checks and cleanup were real. This is integration acceptance, not a detection benchmark.

Results: B05 own-read confirmed (135/238 exchanges); B06 redirect confirmed (13/38); B06 password re-authentication confirmed (118/194). Full repository tests: 1307 passed, 24 skipped. Opt-in fixture tests: 3 passed.

Each folder contains campaign outputs, canonical verification records and a per-run SHA256 seal. See source-provenance.json for checkout and implementation hashes.
