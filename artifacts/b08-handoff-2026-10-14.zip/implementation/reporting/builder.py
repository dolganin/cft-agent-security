from __future__ import annotations

from pipeline.policy import classify_finding_gate
from schemas.report import (
    CIGateImpact,
    FinalReport,
    PolicyDecisionSummary,
    ReportFinding,
    SandboxActionSummary,
    VerificationSummary,
)
from schemas.state import AgentState
from security.error_redaction import redact_error_message

_ALLOWED_STATUSES = {
    "confirmed",
    "rejected",
    "inconclusive",
    "policy_blocked",
}

_EXPLANATIONS = {
    "confirmed": (
        "Capability-specific Evidence confirmed the reported security condition "
        "within the recorded evidence scope."
    ),
    "rejected": (
        "Capability-specific Evidence rejected the reported security condition "
        "within the recorded evidence scope."
    ),
    "inconclusive": (
        "The workflow ended without terminal capability-specific Evidence."
    ),
    "policy_blocked": (
        "Validator denied the proposed verification action according to policy."
    ),
}

_NEXT_STEPS = {
    "confirmed": (
        "Remediate the verified condition, then rerun SAST and the same bounded "
        "verification capability."
    ),
    "rejected": (
        "Retain the Evidence for audit and review whether the originating SAST rule "
        "needs tuning."
    ),
    "inconclusive": (
        "Collect stronger approved Evidence or add a bounded verification capability "
        "before making a terminal claim."
    ),
    "policy_blocked": (
        "Use an allowlisted verification strategy or change policy through operator review."
    ),
}

_VERIFICATION_LIMITATIONS = {
    "runtime_user_verified": "Runtime container user identity was not verified.",
    "runtime_auth_verified": "Runtime authentication behavior was not verified.",
    "browser_execution_verified": "Browser-side execution was not verified.",
}


def build_final_report(state: AgentState) -> FinalReport:
    # Re-resolve source reviews at report time: a source mutation during a
    # workflow must invalidate the initial assessment, not survive in a report.
    if state.get("scoring_review") is not None:
        from scoring.review import score_state
        state = {**state, **score_state(state)}
    # В отчет попадает только терминальный статус, промежуточное состояние не должно выглядеть вердиктом
    status = str(state.get("status", "inconclusive"))
    if status not in _ALLOWED_STATUSES:
        status = "inconclusive"

    finding = state["finding"]
    evidence = list(state.get("evidence", []))
    action = state.get("proposed_action")
    validation = state.get("validation")
    analysis = state.get("analysis")
    hypothesis = state.get("hypothesis")

    if validation is None:
        validator_decision = "not_run"
        validator_reason = None
    elif validation.approved:
        validator_decision = "approved"
        validator_reason = validation.reason
    else:
        validator_decision = "denied"
        validator_reason = validation.reason

    verification = VerificationSummary(
        action_id=action.id if action is not None else None,
        capability=action.tool if action is not None else None,
        target=action.target if action is not None else None,
        environment=action.environment if action is not None else None,
        validator_decision=validator_decision,
        validator_reason=validator_reason,
        evidence_count=len(evidence),
        evidence_types=list(dict.fromkeys(item.type for item in evidence)),
        decision_basis=_decision_basis(state, status),
    )
    gate = classify_finding_gate(
        finding_id=finding.id,
        status=status,
        context_level=(
            state["context_priority"].level
            if state.get("context_priority") is not None
            else None
        ),
        cvss_severity=(
            state["cvss"].severity if state.get("cvss") is not None else None
        ),
        pr_classification=(
            finding.pr_context.classification
            if finding.pr_context is not None
            else None
        ),
    )

    return FinalReport(
        finding_id=finding.id,
        finding=ReportFinding(
            id=finding.id,
            source=finding.source,
            rule_id=finding.rule_id,
            title=finding.title,
            description=finding.description,
            severity=finding.severity,
            service=finding.service,
            file=finding.file,
            line_start=finding.line_start,
            line_end=finding.line_end,
            pr_context=finding.pr_context,
            provenance=finding.provenance,
        ),
        status=status,
        analysis_summary=analysis.summary if analysis is not None else None,
        risk_signals=list(analysis.risk_signals) if analysis is not None else [],
        code_context=state.get("code_context"),
        architecture_context=state.get("architecture_context"),
        hypothesis=hypothesis.statement if hypothesis is not None else None,
        hypothesis_confidence=(hypothesis.confidence if hypothesis is not None else None),
        verification=verification,
        cvss=state.get("cvss"),
        context_priority=state.get("context_priority"),
        technical_severity=state.get("technical_severity"),
        scoring_review_resolution=state.get("scoring_review_resolution"),
        evidence=evidence,
        sandbox_actions=_sandbox_actions(state),
        policy_decisions=_policy_decisions(state),
        agent_decisions=list(state.get("decision_history", [])),
        ci_gate_impact=CIGateImpact(
            effect=gate.effect,
            category=gate.category,
            reason=gate.reason,
        ),
        explanation=_EXPLANATIONS[status],
        limitations=_limitations(state, status),
        next_step=_NEXT_STEPS[status],
        iterations=int(state.get("iteration_count", 0)),
        stop_reason=state.get("stop_reason"),
        binding_resolution=state.get("binding_resolution"),
    )


def _sandbox_actions(state: AgentState) -> list[SandboxActionSummary]:
    history = list(state.get("action_history", []))
    if history:
        return [
            SandboxActionSummary(
                action_id=item.action.id,
                capability=item.action.tool,
                target=item.action.target,
                environment=item.action.environment,
                purpose=item.action.purpose,
                parameter_names=sorted(item.action.parameters),
                execution_status=(item.execution.status if item.execution is not None else None),
                exit_code=(item.execution.exit_code if item.execution is not None else None),
                timed_out=(item.execution.timed_out if item.execution is not None else False),
                duration_ms=(
                    item.execution.duration_ms if item.execution is not None else None
                ),
                command=_display_command(item.action),
                cwd=_display_cwd(item.action),
                stdout=_display_output(
                    item.execution.stdout if item.execution is not None else ""
                ),
                stderr=_display_output(
                    item.execution.stderr if item.execution is not None else ""
                ),
                sandbox_session_id=state.get("sandbox_session_id"),
                artifact_refs=(
                    list(item.execution.artifacts) if item.execution is not None else []
                ),
            )
            for item in history
        ]

    action = state.get("proposed_action")
    if action is None:
        return []
    execution = state.get("execution")
    return [
        SandboxActionSummary(
            action_id=action.id,
            capability=action.tool,
            target=action.target,
            environment=action.environment,
            purpose=action.purpose,
            parameter_names=sorted(action.parameters),
            execution_status=execution.status if execution is not None else None,
            exit_code=execution.exit_code if execution is not None else None,
            timed_out=execution.timed_out if execution is not None else False,
            duration_ms=execution.duration_ms if execution is not None else None,
            command=_display_command(action),
            cwd=_display_cwd(action),
            stdout=_display_output(execution.stdout if execution is not None else ""),
            stderr=_display_output(execution.stderr if execution is not None else ""),
            sandbox_session_id=state.get("sandbox_session_id"),
            artifact_refs=(list(execution.artifacts) if execution is not None else []),
        )
    ]


def _display_command(action) -> list[str]:
    if action.tool == "sandbox_command":
        raw = action.parameters.get("argv")
        if not isinstance(raw, list):
            return []
        return [
            redact_error_message(str(item), max_length=1024)
            for item in raw[:32]
        ]

    fixed_invocations = {
        "inspect_javascript_security": ("artifact_id", "line", "check"),
        "verify_sql_injection": ("artifact_id", "line", "mode", "check"),
        "verify_sensitive_directory": ("artifact_id", "line", "check"),
    }
    if action.tool in fixed_invocations:
        invocation = [action.tool]
        if action.tool == "verify_sql_injection":
            invocation.extend(["--method", "POST" if action.parameters.get("mode") == "authentication" else "GET"])
        elif action.tool == "verify_sensitive_directory":
            invocation.extend(["--method", "GET", "--metadata-only"])
        if action.endpoint:
            invocation.extend(["--endpoint", redact_error_message(action.endpoint, max_length=1024)])
        for name in fixed_invocations[action.tool]:
            value = action.parameters.get(name)
            if value is not None:
                invocation.extend([f"--{name.replace('_', '-')}", redact_error_message(str(value), max_length=1024)])
        return invocation

    displayable_parameters = {
        "inspect_dockerfile_user": ("artifact_id",),
        "inspect_python_password_assignment": ("artifact_id",),
        "inspect_react_dangerous_html_flow": (
            "frontend_artifact_id",
            "model_artifact_id",
            "serializer_artifact_id",
            "view_artifact_id",
            "field",
        ),
    }.get(action.tool)
    if displayable_parameters is None:
        return []

    invocation = [action.tool]
    for name in displayable_parameters:
        value = action.parameters.get(name)
        if isinstance(value, str) and value:
            invocation.extend(
                [
                    f"--{name.replace('_', '-')}",
                    redact_error_message(value, max_length=1024),
                ]
            )
    return invocation


def _display_cwd(action) -> str | None:
    if action.tool != "sandbox_command":
        return None
    raw = action.parameters.get("cwd")
    if not isinstance(raw, str) or not raw:
        return None
    return redact_error_message(raw, max_length=1024)


def _display_output(value: str) -> str | None:
    if not value:
        return None
    redacted = "\n".join(
        redact_error_message(line, max_length=8192)
        for line in value.splitlines()
    )
    if len(redacted) <= 8192:
        return redacted
    return f"{redacted[:8189]}..."


def _policy_decisions(state: AgentState) -> list[PolicyDecisionSummary]:
    history = list(state.get("action_history", []))
    if history:
        return [
            PolicyDecisionSummary(
                action_id=item.validation.action_id,
                decision="approved" if item.validation.approved else "denied",
                reason=item.validation.reason,
                rules=list(item.validation.policy_rules),
            )
            for item in history
        ]

    validation = state.get("validation")
    if validation is None:
        return []
    return [
        PolicyDecisionSummary(
            action_id=validation.action_id,
            decision="approved" if validation.approved else "denied",
            reason=validation.reason,
            rules=list(validation.policy_rules),
        )
    ]


def _decision_basis(state: AgentState, status: str) -> str:
    if state.get("stop_reason") in {
        "step_budget_exhausted",
        "wall_clock_budget_exhausted",
    }:
        return "agent_budget"
    if status == "policy_blocked":
        return "validator_policy"

    evidence = list(state.get("evidence", []))
    # Терминальный Evidence > интерпретация LLM
    if status in {"confirmed", "rejected"} and any(
        item.verdict == status for item in evidence
    ):
        return "capability_specific_evidence"

    if status == "inconclusive" and int(state.get("iteration_count", 0)) >= int(
        state.get("max_steps", state.get("max_iterations", 2))
    ):
        return "iteration_limit"

    return "workflow_state"


def _limitations(state: AgentState, status: str) -> list[str]:
    limitations: list[str] = []
    priority = state.get("context_priority")
    if priority is not None and priority.assessment_status != "assessed":
        limitations.append("Context Priority is provisional; unknown inputs: "
                           + ", ".join(priority.unknown_inputs))
    review = state.get("scoring_review_resolution")
    if review is not None:
        limitations.extend(review.diagnostics)

    for item in state.get("evidence", []):
        for key, message in _VERIFICATION_LIMITATIONS.items():
            if item.observation.facts.get(key) is False:
                limitations.append(message)

    if status == "policy_blocked":
        limitations.append("No verification action was executed after Validator denial.")
    elif status == "inconclusive":
        limitations.append("No terminal capability-specific Evidence was obtained.")

    if state.get("stop_reason") == "step_budget_exhausted":
        limitations.append("Agent stopped because the configured step budget was exhausted.")
    elif state.get("stop_reason") == "wall_clock_budget_exhausted":
        limitations.append("Agent stopped because the wall-clock budget was exhausted.")

    return list(dict.fromkeys(limitations))
