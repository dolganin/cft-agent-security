B06 handoff: auth/redirect runtime acceptance and code support gate.
Extract to any directory. Verify MANIFEST-SHA256.json before review.
In an up-to-date agent checkout: python -m app.b06_replay --input <extracted>/acceptance --output artifacts/b06-replay-new.json
This package is capability acceptance, not a full Juice Shop discovery benchmark.
